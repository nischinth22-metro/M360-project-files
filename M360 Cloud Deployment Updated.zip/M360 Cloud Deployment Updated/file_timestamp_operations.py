from datetime import datetime
from sftp_server_operations import *
import os


class File_Timestamp_Operations:

    def __init__(self):
        self.ftp = None
        self.ssh = None
        self.sftp = SFTP_Server_Operations("pp2.mft.metronom.com", "miag_360",
                                           "vj7%P,rVm[.0utxGHRV##<ia", 10122)

    def getFileTimestamp(self, filename):
        self.ssh = self.sftp.connect()
        self.ftp = self.ssh.open_sftp()
        creation_timestamp = str(self.ftp.stat(os.path.join(f"/MIAG_360/dummy/{filename}")))[-14:-2]
        current_year = datetime.now().year
        creation_timestamp_with_year = f"{creation_timestamp} {current_year}"
        date_format = "%d %b %H:%M %Y"
        datetime_obj = datetime.strptime(creation_timestamp_with_year, date_format)
        self.ftp.close()
        self.sftp.disconnect()
        return datetime_obj
