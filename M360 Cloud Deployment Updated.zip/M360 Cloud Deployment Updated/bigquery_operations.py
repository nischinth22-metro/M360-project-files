from google.cloud import bigquery


class BigQuery_Operations:
    def __init__(self):
        self.client = bigquery.Client()

    def extract_IC(self, sdp_supplier_list_for_ic):
        add_string = ""
        for i in range(len(sdp_supplier_list_for_ic)):
            add_string += "'"
            add_string += str(sdp_supplier_list_for_ic[i])
            add_string += "'"
            add_string += ", "
        add_string = add_string[:-2]
        query = f"""
                SELECT LIFNR,BELNR,RENR, REDAT, LFSNR, GEBRF, GSMWB,
                        WAERS,WENUM,RGDAT,ABGST,T1.GJAHR,DEBNOTNO,WEDAT
                FROM
                `metro-bi-dl-tur-prod.ingest_fgtf_mmsic.mmsic_to_dana_gr_invoice_header` AS T1
                LEFT JOIN 
                (SELECT DISTINCT  VORGN , WEDAT, GJAHR from
                `metro-bi-dl-tur-prod.ingest_fgtf_mmsic.mmsic_to_dana_gr_table_header`) AS T2
                ON 
                T1.VORGN = T2.VORGN
                AND 
                T1.GJAHR = T2.GJAHR
                WHERE
                T1.LIFNR 
                IN 
                ({add_string})
                AND 
                T1.GJAHR 
                IN 
                ('2023')
                ORDER BY 
                T1.dana_ingestion_timestamp;
                """
        extracted_ic_df = self.client.query(query).to_dataframe()
        return extracted_ic_df

    def extract_FI(self, sdp_supplier_list_for_fi):
        add_string = ""
        for i in range(len(sdp_supplier_list_for_fi)):
            add_string += str(sdp_supplier_list_for_fi[i])
            add_string += ", "
        add_string = add_string[:-2]
        query = f"""
                select * from 
                metro-bi-wb-mag-figov-s00.data_integrity_proj.sap_tur_360data_BELNR_testdoc 
                where suppl_no 
                in
                ({add_string});
                """
        extracted_fi_df = self.client.query(query).to_dataframe()
        extracted_fi_df = extracted_fi_df.drop('BUZEI', axis=1)
        return extracted_fi_df


# if __name__ == "__main__":
#     bq_ops = BigQuery_Operations()
#     df = bq_ops.extract_IC(['0000020870', '0000020070'])
#     print("Ex df : ", df)
