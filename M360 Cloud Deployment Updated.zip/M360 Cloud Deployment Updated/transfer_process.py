from db_instance_operations import DB_Instance_Operations
from storage_bucket_operations import Storage_Bucket_Operations
from sftp_process import SFTP_Process
import pandas as pd
from bigquery_operations import BigQuery_Operations
from sftp_server_operations import SFTP_Server_Operations


class Transfer_Process:
    def __init__(self):
        self.sftp_process = SFTP_Process()
        self.storage_bucket_operations = Storage_Bucket_Operations()
        self.db_instance_operations = DB_Instance_Operations()
        self.bigquery_operations = BigQuery_Operations()
        self.sftp_server_operations = SFTP_Server_Operations("pp2.mft.metronom.com", "miag_360",
                                                             "vj7%P,rVm[.0utxGHRV##<ia", 10122)

    def transferData(self):
        sftp_file = self.sftp_process.run()
        if sftp_file is None:
            return
        else:
            miag = self.storage_bucket_operations.readFromBucket(sftp_file)

            sdp = self.db_instance_operations.readSDPTable()
            updated_sdp = self.db_instance_operations.updateSDP(sdp, miag)
            self.db_instance_operations.writeSDPTable(updated_sdp)

            sdp_supplier_list_for_ic = self.db_instance_operations.getSupplierNumberForIC()
            extracted_ic_df = self.bigquery_operations.extract_IC(sdp_supplier_list_for_ic)
            self.db_instance_operations.writeICTable(extracted_ic_df)

            sdp_supplier_list_for_fi = self.db_instance_operations.getSupplierNumberForFI()
            extracted_fi_df = self.bigquery_operations.extract_FI(sdp_supplier_list_for_fi)
            self.db_instance_operations.writeFITable(extracted_fi_df)

            ic_df = self.db_instance_operations.readICTable()
            fi_df = self.db_instance_operations.readFITable()

            #MERGE OPERATION CODE
            # merge_df1 = pd.merge(ic_df, fi_df, left_on=['belnr', 'xblnr'], right_on=['belnr', 'xblnr'])
            # merge_df1['belnr'] = merge_df1['belnr'].astype(str)
            # miag['Document number'] = miag['Document number'].astype(str)
            # miag['Document number'] = '0' + miag['Document number']
            # merge_df2 = pd.merge(merge_df1, miag, left_on=['belnr', 'xblnr'],
            #                      right_on=['Document number', 'Invoice number'])
            # print("Merged DF : ", merge_df2)

            # Select actual 27 columns from all 106 columns

            final_output_df = pd.read_csv("C:/Users/sappidi.reddy/Downloads/load.360.35.20240904.001_test.csv",
                                          index_col=False)
            self.db_instance_operations.writeMergedTable(final_output_df)
            self.sftp_server_operations.writeToSFTPServer(final_output_df, sftp_file)


if __name__ == "__main__":
    print("Process started...")
    transfer_process = Transfer_Process()
    transfer_process.transferData()
    print("Process completed successfully...")
