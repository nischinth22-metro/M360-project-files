import os.path
import pandas as pd
from google.cloud import storage
from file_timestamp_operations import File_Timestamp_Operations
from current_timestamp import Current_Timestamp
from sftp_server_operations import SFTP_Server_Operations
import io


class SFTP_File_Operations:
    def __init__(self):
        self.file_name = ""
        self.ssh = None
        self.sftp = SFTP_Server_Operations("pp2.mft.metronom.com", "miag_360",
                                           "vj7%P,rVm[.0utxGHRV##<ia", 10122)
        self.file_timestamp_ops = File_Timestamp_Operations()
        self.current_timestamp = Current_Timestamp("gs://miag-m360-test-bucket/Last_Processed_Timestamp.txt")

    def getAllFiles(self):
        self.ssh = self.sftp.connect()
        files_list = self.sftp.list_dir("/MIAG_360/dummy/")
        self.sftp.disconnect()
        return files_list

    def getRecentFiles(self, files_list):
        recent_files_list = []
        for file in files_list:
            current_file_timestamp = self.file_timestamp_ops.getFileTimestamp(file)
            if current_file_timestamp > self.current_timestamp.read():
                recent_files_list.append(file)
        return recent_files_list

    def mergeFiles(self, recent_files_list, gcs_uri):
        self.current_timestamp.writeNow()
        for file in recent_files_list:
            self.file_name += file[-7:-4]
            self.file_name += "_"
        self.file_name = self.file_name[:-1]
        self.file_name += ".csv"
        csv_files = []
        self.ssh = self.sftp.connect()
        self.sftp = self.ssh.open_sftp()
        for file in recent_files_list:
            with self.sftp.open(os.path.join("/MIAG_360/dummy", file), 'rb') as sftp_file:
                in_mem_file = io.BytesIO(sftp_file.read())
                df = pd.read_csv(in_mem_file)
                csv_files.append(df)
        self.sftp.close()
        merged_df = pd.concat(csv_files, ignore_index=True)
        csv_buffer = io.StringIO()
        merged_df.to_csv(csv_buffer, index=False)
        bucket_name = gcs_uri.split("/")[2]
        file_path = "/".join(gcs_uri.split("/")[3:])
        client = storage.Client()
        bucket = client.get_bucket(bucket_name)
        blob = bucket.blob(f"{file_path}/{self.file_name}")
        blob.upload_from_string(csv_buffer.getvalue(), content_type='text/csv')
        return self.file_name

# if __name__ == "__main__":
#     sftp_file_ops = SFTP_File_Operations()
#     files_list1 = sftp_file_ops.getAllFiles()
#     print("All : ", files_list1)
#     recent_files_list = sftp_file_ops.getRecentFiles(files_list1)
#     print("Recent :", recent_files_list)
#     sftp_file_ops.mergeFiles(recent_files_list, "gs://m360_testing/Downloaded Files/")
#     print("Merged")
