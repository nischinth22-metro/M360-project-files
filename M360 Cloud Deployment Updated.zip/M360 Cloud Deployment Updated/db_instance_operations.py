import pandas as pd
from sqlalchemy import create_engine, text
import pandasql as ps


class DB_Instance_Operations:

    def __init__(self):
        self.db_url = (
            "postgresql+psycopg2://postgres:9rk$Y}gib9kZEucj@10.32.111.54:5432/MIAG-M360_UAT"
            "?sslmode=require"
            "&sslrootcert=C:/Users/sappidi.reddy/Downloads/hada-bsc-miag-m360-psql-pp-server-ca.pem"
            "&sslcert=C:/Users/sappidi.reddy/Downloads/hada-bsc-miag-m360-psql-pp-client-cert.pem"
            "&sslkey=C:/Users/sappidi.reddy/Downloads/hada-bsc-miag-m360-psql-pp-client-key.pem"
        )
        self.engine = create_engine(self.db_url)
        # print("Engine creation successful...")

    def readSDPTable(self):
        # query = "Delete from sdp_pool;"
        # with self.engine.connect() as connection:
        #     connection.execute(text(query))
        #     connection.commit()
        # print("Rows deleted")
        query = "select * from sdp_pool"
        sdp_df = pd.read_sql_query(query, self.engine)
        return sdp_df

    def updateSDP(self, sdp, miag):
        sq1 = "SELECT DISTINCT `Supplier number (Sales Line)`, `Supplier number (MIAG)`, `Supplier name`, `Contract area` FROM miag"
        miag2 = ps.sqldf(sq1, locals())
        if sdp.shape[0] == 0:
            sdp = miag2.copy()
        else:
            sdpq = "Select distinct * from sdp"
            sdp_dist_df = ps.sqldf(sdpq)
            new_supp_in_sftp_query = "SELECT * from miag2 where `Supplier number (Sales Line)` not in (SELECT `Supplier_Number_Sales` FROM sdp)"
            new_supp_df = ps.sqldf(new_supp_in_sftp_query)
            push_to_sdp_query = "Select `Supplier number (Sales Line)`, `Supplier number (MIAG)`, `Supplier name`, `Contract area` from new_supp_df union Select `Supplier_Number_Sales`, `Supplier_Number_MIAG`, `Supplier_Name`, `Contract_Area` from sdp"
            sdp = ps.sqldf(push_to_sdp_query)
        return sdp

    def writeSDPTable(self, sdp):
        column_mapping = {
            'Supplier number (Sales Line)': 'Supplier_Number_Sales',
            'Supplier number (MIAG)': 'Supplier_Number_MIAG',
            'Supplier name': 'Supplier_Name',
            'Contract area': 'Contract_Area'
        }
        sdp.rename(columns=column_mapping, inplace=True)
        with self.engine.begin() as connection:
            delete_query = text("Delete from sdp_pool")
            connection.execute(delete_query)
            sdp.to_sql('sdp_pool', connection, if_exists='append', index=False)
        # print("Written back to SDP Table of DB Instance...")

    def getSupplierNumberForIC(self):
        new_supplier_list_for_ic = []
        supplier_list_for_ic = self.readSDPTable()['Supplier_Number_Sales'].to_list()
        for i in range(len(supplier_list_for_ic)):
            new_supplier_list_for_ic.append(str(0) + supplier_list_for_ic[i][1:])
        return new_supplier_list_for_ic

    def getSupplierNumberForFI(self):
        new_supplier_list_for_fi = []
        supplier_list_for_fi = self.readSDPTable()['Supplier_Number_Sales'].to_list()
        for i in range(len(supplier_list_for_fi)):
            new_supplier_list_for_fi.append(supplier_list_for_fi[i][5:])
        return new_supplier_list_for_fi

    def writeICTable(self, extracted_ic_df):
        column_mapping = {
            'LIFNR': 'suppl_no',
            'BELNR': 'belnr',
            'RENR': 'xblnr',
            'REDAT': 'zfbdt',
            'LFSNR': 'delivery_note_no',
            'GEBRF': 'amount_in_document_currenct',
            'GSMWB': 'amount_in_local_currency',
            'WAERS': 'waers',
            'WENUM': 'goods_receipt_no',
            'RGDAT': 'invoice_entry_date',
            'ABGST': 'invoice_status',
            'GJAHR': 'gjahr',
            'DEBNOTNO': 'debit_note_no',
            'WEDAT': 'augdt'
        }
        extracted_ic_df.rename(columns=column_mapping, inplace=True)
        with self.engine.connect() as connection:
            delete_query = text("Delete from tbl_ic")
            connection.execute(delete_query)
            connection.commit()
            extracted_ic_df.to_sql('tbl_ic', self.engine, if_exists='append', index=False)
        # print("Written to Intermediate IC Table of DB Instance...")

    def writeFITable(self, extracted_fi_df):
        column_mapping = {
            'MANDT': 'mandt',
            'Document_type': 'document_type',
            'document_type_desc': 'document_type_desc',
            'GJAHR': 'gjahr',
            'BUKRS': 'bukrs',
            'GSBER': 'gsber',
            'PRCTR': 'prctr',
            'store_or_dc': 'store_or_dc',
            'KOSTL': 'kostl',
            'month_in_fin_year': 'month_in_fin_year',
            'BELNR': 'belnr',
            'XBLNR': 'xblnr',
            'AUGBL': 'augbl',
            'AUGDT': 'augdt',
            'ZFBDT': 'zfbdt',
            'ZBD1T': 'zbd1t',
            'ZBD2T': 'zbd2t',
            'NETDT': 'netdt',
            'altkt': 'altkt',
            'hkont': 'hkont',
            'suppl_no': 'supplier_no',
            'BLDAT': 'bldat',
            'BUDAT': 'budat',
            'CPUDT': 'cpudt',
            'partition_date': 'partition_date',
            'dana_ingestion_date': 'dana_ingestion_date',
            'shkzg': 'shkzg',
            'Amount_in_local_currency': 'amount_in_local_currency',
            'Amount_in_document_currency': 'amount_in_document_currency',
            'Tax_in_local_currency': 'tax_in_local_currency',
            'Tax_in_document_currency': 'tax_in_document_currency',
            'WAERS': 'waers',
            'Batch_Input_session_name': 'batch_input_session_name',
            'sgtxt': 'sgtxt'
        }
        extracted_fi_df.rename(columns=column_mapping, inplace=True)
        with self.engine.connect() as connection:
            delete_query = text("Delete from tbl_fi")
            connection.execute(delete_query)
            connection.commit()
        extracted_fi_df.to_sql('tbl_fi', self.engine, if_exists='append', index=False)
        # print("Written to Intermediate FI Table of DB Instance...")

    def writeMergedTable(self, final_output_df):
        column_mapping = {
            'COMPANY_CODE': 'invoice_status_internal',
            'SUPPLIER_NO': 'supplier_no',
            'MIAG_SUPPLIER_NO': 'miag_supplier',
            'ORDER_NO': 'order_no',
            'DOC_TYPE': 'doc_type',
            'INVOICE_NO': 'invoice_no',
            'INVOICE_DATE': 'invoice_date',
            'DELIVERY_NOTE_NO': 'delivery_note_no',
            'CURRENCY': 'currency',
            'PRE_FINANCE_DATE': 'pre_finance_date',
            'GOODS_RECEIPT_NO': 'goods_receipt_no',
            'INVOICE_ENTRY_DATE': 'invoice_entry_date',
            'INVOICE_STATUS': 'invoice_status',
            'NET_DUE_DATE': 'net_due_date',
            'DEBIT_NOTE_NO': 'debit_note_no',
            'REMITTANCE_ADVICE_NO': 'remittance_advice_no',
            'DOCUMENT_NO': 'document_no',
            'STORE_NO': 'store_no',
            'ARKTX': 'arktx',
            'CLEARING_DATE': 'clearing_date',
            'TOTAL_AMT_DC': 'total_amt_dc',
            'TOTAL_VAT_DC': 'total_vat_dc',
            'GOODS_RECEIPT_DATE': 'goods_receipt_date',
            'MATCHING_DATE': 'matching_date',
            'MATCH_STATUS': 'match_status',
            'SYNC_DATE': 'sync_date',
            'SYNC_STATUS': 'sync_status'
        }
        date_columns = ['INVOICE_DATE', 'PRE_FINANCE_DATE', 'INVOICE_ENTRY_DATE', 'NET_DUE_DATE', 'CLEARING_DATE',
                        'GOODS_RECEIPT_DATE', 'MATCHING_DATE', 'SYNC_DATE']
        for column in date_columns:
            final_output_df[column] = pd.to_datetime(final_output_df[column], format='%d.%m.%Y').dt.strftime('%m-%d-%Y')
        final_output_df.rename(columns=column_mapping, inplace=True)
        with self.engine.connect() as connection:
            delete_query = text("Delete from tbl_merged_data")
            connection.execute(delete_query)
            connection.commit()
        final_output_df.to_sql('tbl_merged_data', self.engine, if_exists='append', index=False)
        # print("Written to Final 360 Table of DB Instance...")

    def readICTable(self):
        query = "select * from tbl_ic"
        ic_df = pd.read_sql_query(query, self.engine)
        return ic_df

    def readFITable(self):
        query = "select * from tbl_fi"
        fi_df = pd.read_sql_query(query, self.engine)
        return fi_df

    def read360Table(self):
        query = "select * from tbl_merged_data"
        final_df = pd.read_sql_query(query, self.engine)
        return final_df


# if __name__ == "__main__":
#     db_instance_ops = DB_Instance_Operations()
#     final1_df = db_instance_ops.read360Table()
#     print("Final df : ", final1_df)
#     print("Final df shape : ", final1_df.shape)
