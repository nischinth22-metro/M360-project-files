from io import StringIO
import paramiko
import os


class SFTP_Server_Operations:

    def __init__(self, host, username, password, port):
        self.ftp = None
        self.host = host
        self.username = username
        self.password = password
        self.port = port
        self.ssh_client = paramiko.SSHClient()

    def connect(self):
        try:
            self.ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            self.ssh_client.connect(hostname=self.host, port=self.port, username=self.username, password=self.password)
            return self.ssh_client
        except Exception as e:
            print(e)

    def list_dir(self, path):
        self.ftp = self.ssh_client.open_sftp()
        dir_list = self.ftp.listdir(path)
        self.ftp.close()
        return dir_list

    def disconnect(self):
        self.ssh_client.close()

    def download(self, remote_path, local_path):
        try:
            self.ftp = self.ssh_client.open_sftp()
            path, _ = os.path.split(local_path)
            if not os.path.isdir(path):
                try:
                    os.makedirs(path)
                except Exception as e:
                    raise Exception(e)
            self.ftp.get(remote_path, local_path)
            self.ftp.close()
        except Exception as e:
            raise Exception(e)

    def delete(self, remote_path):
        try:
            self.ftp = self.ssh_client.open_sftp()
            self.ftp.remove(remote_path)
        except Exception as e:
            print(e)

    def upload(self, local_path, remote_path):
        try:
            self.ftp = self.ssh_client.open_sftp()
            self.ftp.put(local_path, remote_path)
        except Exception as e:
            raise Exception(e)

    def writeToSFTPServer(self, final_data_df, file_name):
        csv_buffer = StringIO()
        final_data_df.to_csv(csv_buffer, index=False)
        csv_data = csv_buffer.getvalue()
        ssh = self.connect()
        self.ftp = self.ssh_client.open_sftp()
        with self.ftp.open(f'/MIAG_360/output_files/{file_name[:-4]}_output.csv', 'w') as f:
            f.write(csv_data)
        self.ftp.close()
        self.disconnect()


# if __name__ == "__main__":
#     sftp_server_ops = SFTP_Server_Operations("pp2.mft.metronom.com", "miag_360",
#                                              "vj7%P,rVm[.0utxGHRV##<ia", 10122)
#     sftp_server_ops.connect()
#     # sftp_server_ops.delete(r"/MIAG_360/dummy/miag.35.258800.20240517.333.csv")
#     # sftp_server_ops.delete(r"/MIAG_360/dummy/miag.35.258800.20240517.222.csv")
#     # sftp_server_ops.delete(r"/MIAG_360/dummy/111.csv_output.csv")
#     sftp_server_ops.upload(
#         r"C:/Users/sappidi.reddy/Documents/M360 Project Files/MIAG Location/miag.35.258800.20240517.333.csv",
#         r"/MIAG_360/dummy/miag.35.258800.20240517.333.csv")
#     sftp_server_ops.upload(
#         r"C:/Users/sappidi.reddy/Documents/M360 Project Files/MIAG Location/miag.35.258800.20240517.444.csv",
#         r"/MIAG_360/dummy/miag.35.258800.20240517.444.csv")
#     sftp_server_ops.upload(
#         r"C:/Users/sappidi.reddy/Documents/M360 Project Files/MIAG Location/miag.35.258800.20240517.555.csv",
#         r"/MIAG_360/dummy/miag.35.258800.20240517.555.csv")
#
#
#     # sftp_server_ops.delete(r"/MIAG_360/dummy/miag.35.258800.20240517.333.csv")
#     # sftp_server_ops.delete(r"/MIAG_360/dummy/miag.35.258800.20240517.444.csv")
#     # sftp_server_ops.delete(r"/MIAG_360/dummy/miag.35.258800.20240517.555.csv")
#     #
#     # sftp_server_ops.delete(r"/MIAG_360/output_files/111_output.csv")
#     # sftp_server_ops.delete(r"/MIAG_360/output_files/222_333_output.csv")
#     # sftp_server_ops.delete(r"/MIAG_360/output_files/555_444_output.csv")
#
#     print("Input Files : ")
#     print(sftp_server_ops.list_dir(r"/MIAG_360/dummy"))
#     # sftp_server_ops.delete(r"/MIAG_360/dummy/111.csv"
#     print("Output Files : ")
#     print(sftp_server_ops.list_dir(r"/MIAG_360/output_files"))
#     sftp_server_ops.disconnect()
