from sftp_file_operations import *


class SFTP_Process:
    def __init__(self):
        self.sftp_file_operations = SFTP_File_Operations()
        self.gcs_uri = "gs://miag-m360-test-bucket/Downloaded Files"

    def run(self):
        all_files = self.sftp_file_operations.getAllFiles()
        new_files = self.sftp_file_operations.getRecentFiles(all_files)
        if len(new_files) == 0:
            return None
        else:
            # print("Fetching recently uploaded files...")
            new_file_name = self.sftp_file_operations.mergeFiles(new_files, self.gcs_uri)
            # print(f"New Files merged into one...{new_file_name}")
            return new_file_name


# if __name__ == "__main__":
#     sftp_process = SFTP_Process()
#     sftp_process.run()
