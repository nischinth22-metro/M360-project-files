import pandas as pd
from google.cloud import storage
import io
from sftp_server_operations import SFTP_Server_Operations


class Storage_Bucket_Operations:

    def __init__(self):
        self.bucket_name = "miag-m360-test-bucket"
        self.download_files_path = "Downloaded Files"
        self.sftp = SFTP_Server_Operations("pp2.mft.metronom.com", "miag_360",
                                           "vj7%P,rVm[.0utxGHRV##<ia", 10122)

    def readFromBucket(self, sftp_file):
        client = storage.Client(project='cf-hada-bsc-mcctk-mia-kg')
        bucket = client.get_bucket(self.bucket_name)
        blob = bucket.blob(f"{self.download_files_path}/{sftp_file}")
        csv_data = blob.download_as_text()
        sftp = pd.read_csv(io.StringIO(csv_data), index_col=False)
        return sftp


# if __name__ == "__main__":
#     storage_bucket_ops = Storage_Bucket_Operations()
#     print(storage_bucket_ops.readFromBucket("111_222_333.csv"))