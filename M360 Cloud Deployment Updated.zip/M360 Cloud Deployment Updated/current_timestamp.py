from datetime import datetime
from google.cloud import storage


class Current_Timestamp:

    def __init__(self, file_path):
        self.bucket_name = file_path.split("/")[2]
        self.file_name = "/".join(file_path.split("/")[3:])
        self.project = 'cf-hada-bsc-mcctk-mia-kg'

    def write(self):
        client = storage.Client(self.project)
        bucket = client.get_bucket(self.bucket_name)
        blob = bucket.blob(self.file_name)
        date_to_write = datetime(2024, 8, 1, 17, 50, 0)
        date_string = date_to_write.strftime("%d %b %H:%M %Y")
        blob.upload_from_string(date_string + '\n')

    def read(self):
        client = storage.Client(self.project)
        bucket = client.get_bucket(self.bucket_name)
        blob = bucket.blob(self.file_name)
        content = blob.download_as_text()
        date_format = "%d %b %H:%M %Y"
        datetime_obj = datetime.strptime(content.strip(), date_format)
        return datetime_obj

    def writeNow(self):
        client = storage.Client(self.project)
        bucket = client.get_bucket(self.bucket_name)
        blob = bucket.blob(self.file_name)
        date_to_write = datetime.now()
        date_string = date_to_write.strftime("%d %b %H:%M %Y")
        blob.upload_from_string(date_string + '\n')


# if __name__ == "__main__":
#     current_timestamp = Current_Timestamp("gs://miag-m360-test-bucket/Last_Processed_Timestamp.txt")
#     print(current_timestamp.write())
